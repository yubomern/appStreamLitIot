#ifndef OPTIONS_H
#define OPTIONS_H

// ─── Platform Detection ───────────────────────────────────────────────────────
#if defined(_WIN32) || defined(_WIN64)
    #define PLATFORM_WINDOWS
#elif defined(__linux__)
    #define PLATFORM_LINUX
#else
    #error "Unsupported platform: only Windows and Linux are supported"
#endif

// ─── Feature Flags ────────────────────────────────────────────────────────────
#define USE_SYSTEM_METRICS
#define ENABLE_JSON_EXPORT/// ← This line enables JSON export
#define ENABLE_CSV_EXPORT

// ─── Constants ────────────────────────────────────────────────────────────────
#define MAX_STACK_SIZE   32
#define FILE_NAME_LEN   256
#define FUNC_NAME_LEN   128
#define PROCESS_NAME_LEN  64
#define CAUSE_LEN       256
#define SEVERITY_LEN     32
#define RECOMMENDATION_LEN 256

// ─── Pointer-width integer ────────────────────────────────────────────────────
#include <stdint.h>
#include <stddef.h>

#if SIZE_MAX == UINT32_MAX
    typedef int32_t  INTEGER_TYPE;
#elif SIZE_MAX == UINT64_MAX
    typedef int64_t  INTEGER_TYPE;
#else
    #error "Unsupported pointer width"
#endif

#endif // OPTIONS_H
