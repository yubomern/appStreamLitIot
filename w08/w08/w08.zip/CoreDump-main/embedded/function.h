#ifndef FUNCTION_H
#define FUNCTION_H

void HandlePreviousCrash();
void SignalHandler(int signum);
void TriggerTestCrash();

#endif
