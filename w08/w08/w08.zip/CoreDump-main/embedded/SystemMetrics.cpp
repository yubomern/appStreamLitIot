#include "SystemMetrics.h"
#include "Platform.h"
#include <cstring>
#include <cstdio>

// ═════════════════════════════════════════════════════════════════════════════
//  LINUX implementation
// ═════════════════════════════════════════════════════════════════════════════
#ifdef PLATFORM_LINUX

void CaptureSystemMetrics(SystemMetrics* metrics) {
    if (!metrics) return;
    memset(metrics, 0, sizeof(*metrics));

    // ── PID ──────────────────────────────────────────────────────────────────
    metrics->process_id = PlatformGetPid();

    // ── Process name ─────────────────────────────────────────────────────────
    FILE* fp = fopen("/proc/self/comm", "r");
    if (fp) {
        if (fgets(metrics->process_name, sizeof(metrics->process_name), fp)) {
            // Strip trailing newline
            char* nl = strchr(metrics->process_name, '\n');
            if (nl) *nl = '\0';
        }
        fclose(fp);
    } else {
        strncpy(metrics->process_name, "unknown", sizeof(metrics->process_name) - 1);
    }

    // ── CPU usage (snapshot from /proc/stat) ──────────────────────────────────
    FILE* stat = fopen("/proc/stat", "r");
    if (stat) {
        unsigned long long user, nice, sys, idle, iowait, irq, softirq;
        if (fscanf(stat, "cpu %llu %llu %llu %llu %llu %llu %llu",
                   &user, &nice, &sys, &idle, &iowait, &irq, &softirq) == 7) {
            unsigned long long total     = user + nice + sys + idle + iowait + irq + softirq;
            unsigned long long idle_all  = idle + iowait;
            metrics->cpu_usage_percent   = (total > 0)
                ? 100.0 * (1.0 - static_cast<double>(idle_all) / total)
                : 0.0;
        }
        fclose(stat);
    }

    // ── Memory (from /proc/meminfo) ───────────────────────────────────────────
    FILE* meminfo = fopen("/proc/meminfo", "r");
    if (meminfo) {
        char line[256];
        unsigned long memTotal = 0, memAvailable = 0;
        while (fgets(line, sizeof(line), meminfo)) {
            sscanf(line, "MemTotal: %lu kB",     &memTotal);
            sscanf(line, "MemAvailable: %lu kB", &memAvailable);
        }
        metrics->memory_total_kb = static_cast<uint64_t>(memTotal);
        metrics->memory_used_kb  = static_cast<uint64_t>(
            (memTotal > memAvailable) ? (memTotal - memAvailable) : 0);
        fclose(meminfo);
    }

    // ── Thread count (from /proc/self/status) ─────────────────────────────────
    metrics->thread_count = 1; // safe default
    FILE* status = fopen("/proc/self/status", "r");
    if (status) {
        char line[256];
        while (fgets(line, sizeof(line), status)) {
            if (sscanf(line, "Threads: %d", &metrics->thread_count) == 1) break;
        }
        fclose(status);
    }
}

// ═════════════════════════════════════════════════════════════════════════════
//  WINDOWS implementation
// ═════════════════════════════════════════════════════════════════════════════
#elif defined(PLATFORM_WINDOWS)

#include <windows.h>
#include <psapi.h>
#include <tlhelp32.h>
#pragma comment(lib, "psapi.lib")

static double QueryCpuUsage() {
    FILETIME idleTime, kernelTime, userTime;
    if (!GetSystemTimes(&idleTime, &kernelTime, &userTime)) return 0.0;

    auto toULL = [](const FILETIME& ft) -> unsigned long long {
        return (static_cast<unsigned long long>(ft.dwHighDateTime) << 32) | ft.dwLowDateTime;
    };
    static unsigned long long prevIdle = 0, prevKernel = 0, prevUser = 0;

    unsigned long long curIdle   = toULL(idleTime);
    unsigned long long curKernel = toULL(kernelTime);
    unsigned long long curUser   = toULL(userTime);

    unsigned long long diffIdle   = curIdle   - prevIdle;
    unsigned long long diffKernel = curKernel - prevKernel;
    unsigned long long diffUser   = curUser   - prevUser;

    prevIdle = curIdle; prevKernel = curKernel; prevUser = curUser;

    unsigned long long total = diffKernel + diffUser;
    return (total > 0) ? (100.0 * (total - diffIdle) / total) : 0.0;
}

static int CountProcessThreads(DWORD pid) {
    int count = 0;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (snap == INVALID_HANDLE_VALUE) return 1;
    THREADENTRY32 te = { sizeof(te) };
    if (Thread32First(snap, &te)) {
        do { if (te.th32OwnerProcessID == pid) ++count; }
        while (Thread32Next(snap, &te));
    }
    CloseHandle(snap);
    return count;
}

void CaptureSystemMetrics(SystemMetrics* metrics) {
    if (!metrics) return;
    memset(metrics, 0, sizeof(*metrics));

    // ── PID ──────────────────────────────────────────────────────────────────
    DWORD pid = GetCurrentProcessId();
    metrics->process_id = static_cast<int>(pid);

    // ── Process name ─────────────────────────────────────────────────────────
    char path[MAX_PATH] = {};
    if (GetModuleFileNameA(nullptr, path, MAX_PATH)) {
        const char* name = strrchr(path, '\\');
        strncpy(metrics->process_name, name ? name + 1 : path,
                sizeof(metrics->process_name) - 1);
    } else {
        strncpy(metrics->process_name, "unknown", sizeof(metrics->process_name) - 1);
    }

    // ── CPU usage ─────────────────────────────────────────────────────────────
    metrics->cpu_usage_percent = QueryCpuUsage();

    // ── Memory ───────────────────────────────────────────────────────────────
    MEMORYSTATUSEX ms = { sizeof(ms) };
    if (GlobalMemoryStatusEx(&ms)) {
        metrics->memory_total_kb = static_cast<uint64_t>(ms.ullTotalPhys / 1024);
        metrics->memory_used_kb  = static_cast<uint64_t>(
            (ms.ullTotalPhys - ms.ullAvailPhys) / 1024);
    }

    // ── Thread count ─────────────────────────────────────────────────────────
    metrics->thread_count = CountProcessThreads(pid);
}

#endif // platform
