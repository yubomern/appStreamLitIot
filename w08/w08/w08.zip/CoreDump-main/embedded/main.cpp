#include "CoreDump.h"
#include "Platform.h"
#include <csignal>
#include <cstring>
#include <iostream>
#include "function.h"  
// Defined in test_crash.cpp
//extern void SignalHandler(int signum);
//extern void TriggerTestCrash();


int main(int argc, char* argv[]) {
    //Installation of Signal Handlers
     PlatformInstallSignal(SIGSEGV, SignalHandler);
    PlatformInstallSignal(SIGABRT, SignalHandler);
    PlatformInstallSignal(SIGFPE,  SignalHandler);
    //Check if there's a memory crash.
    HandlePreviousCrash();

///If equal to "--test", the comparison returns 0 → condition true.
   const bool testMode = (argc > 1 && std::strcmp(argv[1], "--test") == 0);
   // const bool testMode = (argc > 1 && std::strcmp(argv[1]) == 0);
    if (testMode) {
        std::cout << "TEST MODE: intentional crash in 2 s...\n";
        PlatformSleepMs(2000);
        TriggerTestCrash();   // never returns
    }

    std::cout << "Application running normally. Press Ctrl+C to quit.\n";

    while (true) {
        PlatformSleepMs(1000);
    }

    return 0;
}
