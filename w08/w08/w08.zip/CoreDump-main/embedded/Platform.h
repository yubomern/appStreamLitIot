#ifndef PLATFORM_H
#define PLATFORM_H

#include "Options.h"

// ─── Sleep (milliseconds) ─────────────────────────────────────────────────────
#ifdef PLATFORM_WINDOWS
    #include <windows.h>
    inline void PlatformSleepMs(unsigned int ms) { Sleep(ms); }
#else
    #include <unistd.h>
    inline void PlatformSleepMs(unsigned int ms) { usleep(ms * 1000u); }
#endif

// ─── Process / Thread IDs ─────────────────────────────────────────────────────
#ifdef PLATFORM_WINDOWS
    #include <windows.h>
    inline int PlatformGetPid()    { return static_cast<int>(GetCurrentProcessId()); }
    inline int PlatformGetTid()    { return static_cast<int>(GetCurrentThreadId()); }
#else
    #include <unistd.h>
    #include <sys/types.h>
    inline int PlatformGetPid()    { return static_cast<int>(getpid()); }
    inline int PlatformGetTid()    { return static_cast<int>(gettid()); }
#endif

// ─── Stack backtrace ──────────────────────────────────────────────────────────
#ifdef PLATFORM_WINDOWS
    #include <windows.h>
    #include <dbghelp.h>
    // Capture return addresses into buffer; returns frame count
    inline int PlatformBacktrace(void** buffer, int maxFrames) {
        return static_cast<int>(
            CaptureStackBackTrace(0, static_cast<DWORD>(maxFrames), buffer, nullptr));
    }
#else
    #include <execinfo.h>
    inline int PlatformBacktrace(void** buffer, int maxFrames) {
        return backtrace(buffer, maxFrames);
    }
#endif

// ─── Signal handling ──────────────────────────────────────────────────────────
#include <csignal>
inline void PlatformInstallSignal(int sig, void (*handler)(int)) {
    signal(sig, handler);//If  receives a signal, execute the handler function.
}

#endif // PLATFORM_H
