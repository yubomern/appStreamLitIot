#include "CoreDump.h"
#include "Platform.h"
#include <csignal>
#include <cstdlib>
#include <iostream>


void HandlePreviousCrash() {
    //check if there was a previous crash and recover your data
    const CoreDumpData* dump = CoreDumpManager::Instance().Get();
    if (!dump) return; //// If empty → we leave 

    std::cout << "\n=== PREVIOUS CRASH DETECTED ===\n";
    std::cout << "  Date      : " << dump->date_time        << '\n';
    std::cout << "  File      : " << dump->file_name << ':' << dump->line_number << '\n';
    std::cout << "  Function  : " << dump->function_name    << '\n';
    std::cout << "  Cause     : " << dump->analysis.probable_cause << '\n';
    std::cout << "  Severity  : " << dump->analysis.severity       << '\n';
    std::cout << "  Confidence: " << dump->analysis.confidence_score << "%\n";
    std::cout << "================================\n\n";

#ifdef ENABLE_JSON_EXPORT
    CoreDumpManager::Instance().ExportTo(ExportFormat::JSON, "/tmp/last_crash.json");
    std::cout << "[CoreDump] JSON exported to /tmp/last_crash.json\n";
#endif
#ifdef ENABLE_CSV_EXPORT
    CoreDumpManager::Instance().ExportTo(ExportFormat::CSV,  "/tmp/last_crash.csv");
    std::cout << "[CoreDump] CSV  exported to /tmp/last_crash.csv\n";
#endif

    CoreDumpManager::Instance().Reset();   // clear for next run
}




// ─── Signal handler ──────────────────────────────────────────────────────────
// Called automatically when SIGSEGV / SIGABRT / SIGFPE fires.
void SignalHandler(int signum) {
    FaultType type = FaultType::Unknown;
    switch (signum) {
        case SIGSEGV: type = FaultType::SegmentationFault;  break;
        case SIGABRT: type = FaultType::AbortSignal;         break;
        case SIGFPE:  type = FaultType::HardwareException;   break;
        default:      break;
    }

    CoreDumpManager::Instance().Store(nullptr, __FILE__, __LINE__,
                                      static_cast<uint32_t>(signum), type);

#ifdef ENABLE_JSON_EXPORT
    CoreDumpManager::Instance().ExportTo(ExportFormat::JSON, "/tmp/crash_dump.json");
#endif
#ifdef ENABLE_CSV_EXPORT
    CoreDumpManager::Instance().ExportTo(ExportFormat::CSV,  "/tmp/crash_dump.csv");
#endif
//confirmation message
    std::cerr << "[CoreDump] Signal " << signum << " captured and saved.\n";
    exit(1);
}

// ─── Call chain that leads to a crash ────────────────────────────────────────
static void Call3() {
#ifdef HARD_FAULT_TEST
    // Divide-by-zero → SIGFPE
    volatile int zero = 0;
    volatile int result = 1 / zero;
    (void)result;
#else
    //// indicate the file and line where the error occurred.
    std::cerr << "ASSERTION FAILED: " << __FILE__ << ":" << __LINE__ << "\n";
    raise(SIGABRT);///Sends the SIGABRT signal to the process.
#endif
}

static void Call2() { Call3(); }
static void Call1() { Call2(); }

// ─── Entry point for the crash test ─────────────────────────────────────────
void TriggerTestCrash() {
    Call1();   // Call1 → Call2 → Call3 → CRASH
}
