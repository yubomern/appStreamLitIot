#!/bin/bash
# Script de collecte des crash dumps

DUMP_DIR="/var/log/crashes"
SERVER_URL="http://server/crash-upload"

# Créer le dossier si inexistant
mkdir -p $DUMP_DIR

# Vérifier si un crash dump existe
if [ -f "/tmp/crash_dump.json" ]; then
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    
    # Copier avec timestamp
    cp /tmp/crash_dump.json "$DUMP_DIR/crash_$TIMESTAMP.json"
    
    # Envoyer au serveur
    curl -X POST -F "file=@$DUMP_DIR/crash_$TIMESTAMP.json" $SERVER_URL
    
    # Nettoyer
    rm /tmp/crash_dump.json
    
    echo "Crash dump collecté et envoyé: crash_$TIMESTAMP.json"
else
    echo "Aucun crash dump à collecter"
fi