#!/bin/bash
# Envoi automatique au serveur

if [ -z "$1" ]; then
    echo "Usage: $0 <file_path>"
    exit 1
fi

FILE_PATH=$1
SERVER_URL="${CRASH_SERVER_URL:-http://localhost:8501/upload}"

if [ -f "$FILE_PATH" ]; then
    curl -X POST -F "file=@$FILE_PATH" $SERVER_URL
    echo "Fichier envoyé: $FILE_PATH"
else
    echo "Fichier non trouvé: $FILE_PATH"
    exit 1
fi